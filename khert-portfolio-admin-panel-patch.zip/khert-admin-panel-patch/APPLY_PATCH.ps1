param(
  [Parameter(Mandatory = $false)]
  [string]$Target = (Get-Location).Path
)

$ErrorActionPreference = "Stop"

function Require-File([string]$Path, [string]$Label) {
  if (-not (Test-Path $Path)) {
    throw "Missing $Label at: $Path"
  }
}

$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = (Resolve-Path $Target).Path

Require-File (Join-Path $Target "package.json") "package.json"
Require-File (Join-Path $Target "src\components\Comments.tsx") "working comments feature"
Require-File (Join-Path $Target "src\components\Portfolio.tsx") "portfolio component"
Require-File (Join-Path $Target "src\App.tsx") "App component"

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $env:TEMP "khert-portfolio-admin-backup-$timestamp"
New-Item -ItemType Directory -Path $backup -Force | Out-Null

$filesToReplace = @(
  "src\App.tsx",
  "src\comments.css",
  "src\components\Comments.tsx",
  "src\components\Portfolio.tsx",
  "vercel.json"
)

foreach ($relative in $filesToReplace) {
  $source = Join-Path $Target $relative
  if (Test-Path $source) {
    $backupPath = Join-Path $backup $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $backupPath) -Force | Out-Null
    Copy-Item $source $backupPath -Force
  }
}

$patchFiles = @(
  "src\App.tsx",
  "src\admin.css",
  "src\comments.css",
  "src\components\AdminPanel.tsx",
  "src\components\Comments.tsx",
  "src\components\Portfolio.tsx",
  "src\lib\portfolio-content.ts",
  "supabase\migrations\20260914203000_add_portfolio_admin.sql",
  "vercel.json"
)

foreach ($relative in $patchFiles) {
  $source = Join-Path $PatchRoot $relative
  $destination = Join-Path $Target $relative

  Require-File $source "patch file $relative"
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item $source $destination -Force
  Write-Host "Applied $relative"
}

Write-Host ""
Write-Host "Patch applied successfully."
Write-Host "Backup of replaced files: $backup"
Write-Host ""
Write-Host "Next:"
Write-Host "  npm run typecheck"
Write-Host "  npm run build"
Write-Host "  npx supabase@latest db push --dry-run"
Write-Host "  npx supabase@latest db push"
