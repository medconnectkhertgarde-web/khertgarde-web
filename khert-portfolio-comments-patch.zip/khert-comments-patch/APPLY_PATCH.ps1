param(
  [Parameter(Mandatory = $false)]
  [string]$Target = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$Target = (Resolve-Path $Target).Path

$portfolioPath = Join-Path $Target "src/components/Portfolio.tsx"
$supabasePath = Join-Path $Target "src/lib/supabase.ts"
$stylesPath = Join-Path $Target "src/styles.css"
$packagePath = Join-Path $Target "package.json"

foreach ($path in @($portfolioPath, $supabasePath, $stylesPath, $packagePath)) {
  if (-not (Test-Path $path)) {
    throw "Expected portfolio file is missing: $path. Run this patch against the khert-portfolio project root."
  }
}

$portfolio = Get-Content $portfolioPath -Raw
if ($portfolio -notmatch 'import \{ ClinicalStudies \} from "@/components/ClinicalStudies";' -or $portfolio -notmatch '<Contact />') {
  throw "Portfolio.tsx does not match the expected project structure. No files were changed."
}

$supabase = Get-Content $supabasePath -Raw
if ($supabase -notmatch 'persistSession:' -or $supabase -notmatch 'autoRefreshToken:' -or $supabase -notmatch 'detectSessionInUrl:') {
  throw "src/lib/supabase.ts does not match the expected project structure. No files were changed."
}

# Add isolated files first.
$copyFiles = @(
  "src/comments.css",
  "src/components/Comments.tsx",
  "supabase/migrations/20260914190000_add_portfolio_comments.sql"
)

foreach ($relative in $copyFiles) {
  $source = Join-Path $PSScriptRoot $relative
  $destination = Join-Path $Target $relative
  $destinationDirectory = Split-Path $destination -Parent
  New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
  Copy-Item $source $destination -Force
  Write-Host "Applied $relative"
}

# Patch only the three small integration points in Portfolio.tsx.
if ($portfolio -notmatch 'import \{ Comments \} from "@/components/Comments";') {
  $portfolio = $portfolio.Replace(
    'import { ClinicalStudies } from "@/components/ClinicalStudies";',
    "import { ClinicalStudies } from `"@/components/ClinicalStudies`";`r`nimport { Comments } from `"@/components/Comments`";"
  )
}

if ($portfolio -notmatch '\["Comments", "comments"\]') {
  $portfolio = $portfolio.Replace(
    '  ["Contact", "contact"],',
    "  [`"Contact`", `"contact`"],`r`n  [`"Comments`", `"comments`"],"
  )
}

if ($portfolio -notmatch '<Comments />') {
  $portfolio = $portfolio.Replace(
    '        <Contact />',
    "        <Contact />`r`n        <Comments />"
  )
}

Set-Content -Path $portfolioPath -Value $portfolio -Encoding utf8
Write-Host "Patched src/components/Portfolio.tsx"

# Auth was previously disabled because Supabase was read-only. Enable normal browser sessions for Google OAuth.
$supabase = $supabase -replace 'persistSession:\s*false', 'persistSession: true'
$supabase = $supabase -replace 'autoRefreshToken:\s*false', 'autoRefreshToken: true'
$supabase = $supabase -replace 'detectSessionInUrl:\s*false', 'detectSessionInUrl: true'
Set-Content -Path $supabasePath -Value $supabase -Encoding utf8
Write-Host "Patched src/lib/supabase.ts"

Write-Host ""
Write-Host "Comments patch applied. package.json, Drive API files, ClinicalStudies.tsx, styles.css, and environment files were not modified."
