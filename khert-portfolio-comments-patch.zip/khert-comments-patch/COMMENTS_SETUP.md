# Portfolio Comments Patch — Setup

This patch adds a lightweight comments/guestbook section without changing the Google Drive studies integration.

## What it adds

- Public visitors can read the newest 50 active comments.
- Posting requires Supabase Google sign-in.
- Comment text is limited to 150 characters in both the browser and database.
- The database derives the commenter identity from Supabase Auth; the browser cannot choose another user ID/name.
- A 30-second per-user posting cooldown limits accidental/spam bursts.
- Each comment is visible for six months. RLS stops returning it immediately after expiry, and one small daily database job removes expired rows.
- No Realtime subscription, polling, profiles table, Edge Function, or extra API route.
- The existing Google Drive study viewer is untouched.

## 1. Apply on a test Git branch

From the portfolio root:

```powershell
git status
git switch -c feature/portfolio-comments
```

Keep the patch ZIP in the portfolio root, then:

```powershell
$Zip = Join-Path (Get-Location) "khert-portfolio-comments-patch.zip"
$Temp = Join-Path $env:TEMP "khert-comments-patch"
Remove-Item $Temp -Recurse -Force -ErrorAction SilentlyContinue
Expand-Archive -Path $Zip -DestinationPath $Temp -Force
powershell -ExecutionPolicy Bypass -File "$Temp\khert-comments-patch\APPLY_PATCH.ps1" -Target (Get-Location).Path
Remove-Item $Temp -Recurse -Force
```

Verify:

```powershell
git status
```

Expected new/modified files:

- `src/components/Comments.tsx`
- `src/comments.css`
- `src/components/Portfolio.tsx`
- `src/lib/supabase.ts`
- `supabase/migrations/20260914190000_add_portfolio_comments.sql`

No package dependency changes are required because `@supabase/supabase-js` is already installed by the project.

## 2. Apply the database migration

If the repository is already linked to your Supabase project:

```powershell
npx supabase@latest db push --dry-run
npx supabase@latest db push
```

If it is not linked yet:

```powershell
npx supabase@latest login
npx supabase@latest link --project-ref YOUR_PROJECT_REF
npx supabase@latest db push --dry-run
npx supabase@latest db push
```

The migration creates only `public.portfolio_comments`, the protected posting RPC, its indexes/policy, and one daily retention job. It does not modify the clinical studies table.

If the migration reports that `pg_cron` cannot be enabled automatically, enable **Supabase Dashboard → Integrations → Cron**, then rerun `db push`.

## 3. Confirm browser-safe Supabase values

Your local `.env.local` needs:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

Never place the Supabase secret/service-role key in a `VITE_` variable.

## 4. Configure Google sign-in

You can use the same Google Cloud project currently used for the Drive API.

### Google Cloud Console

1. Open the project in **Google Auth Platform**.
2. Under **Branding**, set an app name such as `Khert Laguna Garde Portfolio`, a support email, and developer contact email.
3. Under **Audience**, use External. While locally testing, keep the app in testing and add your own Google account as a test user if Google asks for test users.
4. Open **Clients → Create client**.
5. Application type: **Web application**.
6. Add this Authorized JavaScript origin for local testing:

   `http://localhost:3000`

7. In Supabase, open **Authentication → Providers → Google** and copy the callback URL shown there. It has the form:

   `https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback`

8. Add that exact URL under **Authorized redirect URIs** in the Google OAuth client.
9. Create the client and copy its **Client ID** and **Client Secret**.

### Supabase Dashboard

1. Open **Authentication → Providers → Google**.
2. Enable Google.
3. Paste the Google Client ID and Client Secret.
4. Save.
5. Open **Authentication → URL Configuration**.
6. Add this redirect URL for local testing:

   `http://localhost:3000/**`

The app itself uses Supabase `signInWithOAuth({ provider: "google" })`; no Google token is stored by the portfolio.

## 5. Test locally

Because the portfolio also has a Vercel `/api/studies` function, use Vercel's local dev server instead of plain Vite:

```powershell
npm install
npm run typecheck
npm run build
npx vercel@latest dev
```

Open:

`http://localhost:3000/#comments`

Test all of these:

1. Signed-out visitors can read comments.
2. The comment composer asks for Google sign-in.
3. Google sign-in returns you to the portfolio.
4. Your Google display name/avatar appears, but your email is not displayed.
5. A comment of 1–150 characters posts successfully.
6. The counter does not permit more than 150 characters.
7. Posting again immediately shows the short cooldown message.
8. Sign out; the comment remains readable publicly.
9. The Clinical Studies section and Drive preview still work.

You can verify the database row in **Supabase → Table Editor → portfolio_comments**.

## 6. Commit the tested feature branch

When local testing passes:

```powershell
git add src/components/Comments.tsx src/comments.css src/components/Portfolio.tsx src/lib/supabase.ts supabase/migrations/20260914190000_add_portfolio_comments.sql
git commit -m "Add Google-authenticated portfolio comments"
```

## 7. Configure production OAuth before merging

In the Google OAuth Web client, add your real Vercel production origin under **Authorized JavaScript origins**, for example:

`https://YOUR-PRODUCTION-DOMAIN.vercel.app`

Do not add a path or trailing slash to the Google JavaScript origin.

In **Supabase → Authentication → URL Configuration**:

- Set **Site URL** to your production portfolio URL.
- Add the exact `https://YOUR-PRODUCTION-DOMAIN.vercel.app/` to Redirect URLs.
- Keep the localhost redirect while you still need local testing.

For public visitors to use Google login, make sure the Google Auth app is no longer restricted only to your test-user list when you launch the feature publicly.

## 8. Add Supabase public environment values to Vercel

In the Vercel project add:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`

These are browser/public credentials designed to work with RLS. Do not add a Supabase secret/service-role key to the frontend.

Keep your existing Drive variables exactly as they already are:

- `GOOGLE_DRIVE_FOLDER_URL`
- `GOOGLE_DRIVE_API_KEY`

## 9. Merge into main and deploy through GitHub

From the tested feature branch:

```powershell
git switch main
git pull --ff-only origin main
git merge --ff-only feature/portfolio-comments
git push origin main
```

Vercel will deploy the new `main` commit automatically if GitHub integration is enabled.

After deployment test:

- `/api/studies` still returns Drive studies.
- Clinical study previews still open.
- Comments load while signed out.
- Google sign-in works on the production domain.
- Posting and signing out work.

## Roll back the frontend before merging

If you do not like the feature while testing:

```powershell
git switch main
git branch -D feature/portfolio-comments
```

Because the feature is isolated, the existing production branch remains unchanged until you merge it.
